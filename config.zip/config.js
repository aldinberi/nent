module.exports = {
    MONGODB_URL: 'mongodb+srv://beri:EVHXxPi4m0LP1B6w@cluster0-lsyrc.mongodb.net/nent?retryWrites=true&w=majority',
    JWT_SECRET: 'jPGAkO2aozorwLK8vNca',
    SWAGGER_HOST: 'localhost:3000'
}